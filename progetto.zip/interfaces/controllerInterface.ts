export interface Mediator {
  createGraph(data: any, userId: number): Promise<any>;
  // altri metodi: update, execute, etc.
}
